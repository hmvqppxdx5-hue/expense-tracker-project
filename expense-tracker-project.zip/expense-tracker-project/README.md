# Expense Tracker Project

A full-stack Django Expense Tracker web application with authentication and CRUD operations.
