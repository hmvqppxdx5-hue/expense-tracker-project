from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.hashers import make_password
from django.contrib import messages
from .models import Expense, Category

def home(request):
    return render(request, 'core/home.html')

def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        confirm = request.POST['confirm_password']

        if password != confirm:
            messages.error(request, 'Passwords do not match')
            return redirect('register')

        User.objects.create(
            username=username,
            email=email,
            password=make_password(password)
        )
        return redirect('login')

    return render(request, 'core/register.html')

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(
            request,
            username=username,
            password=password
        )

        if user is not None:
            login(request, user)
            return redirect('dashboard')

    return render(request, 'core/login.html')

@login_required
def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def dashboard(request):
    expenses = Expense.objects.filter(user=request.user)

    total_income = sum(
        e.amount for e in expenses
        if e.transaction_type == 'Income'
    )

    total_expense = sum(
        e.amount for e in expenses
        if e.transaction_type == 'Expense'
    )

    balance = total_income - total_expense

    return render(request, 'core/dashboard.html', {
        'expenses': expenses,
        'total_income': total_income,
        'total_expense': total_expense,
        'balance': balance
    })

@login_required
def add_expense(request):
    categories = Category.objects.all()

    if request.method == 'POST':
        Expense.objects.create(
            user=request.user,
            title=request.POST['title'],
            amount=request.POST['amount'],
            category_id=request.POST['category'],
            transaction_type=request.POST['transaction_type'],
            description=request.POST['description']
        )
        return redirect('dashboard')

    return render(request, 'core/add_expense.html', {
        'categories': categories
    })
